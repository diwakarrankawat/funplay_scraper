class Selectors:
    item = 'a[data-server]'
    item_s = 'a[data-server="{}"]'
    username = 'div.media-user-name'
    amount = 'div.tc-amount'
    price = 'div.tc-price'
    servername = 'div.tc-server'
    servers = 'select[name="server"] option'
